from typing import Dict, List, Tuple, Optional
import logging

import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Model, load_model
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.layers import (
    Input,
    Dense,
    Dropout,
    Embedding,
    Flatten,
    Concatenate,
    Layer,
    LayerNormalization
)

from recommendations.src.domain.dataset_preprocessor import (
    NUMERICAL_INPUTS_FEATURES_KEY,
    NUMERICAL_OUTPUTS_KEY,
)
from recommendations.src.domain.interfaces.classified_embedding_model_interface import (
    ClassifiedEmbeddingModelInterface,
)
from recommendations.src.domain.entites.dataset_analysis import DatasetAnalysis


class KerasAutoencoder(ClassifiedEmbeddingModelInterface):
    def __init__(
        self,
        bottleneck_layer_dim: int | None = None,
        hidden_layer_dim: List[int] | None = None,
        autoencoder: Model | None = None,
        encoder: Model | None = None,
        use_gpu: bool = True,
        gpu_memory_growth: bool = True,
        mixed_precision: bool = False,
    ):
        self.bottleneck_layer_dim = bottleneck_layer_dim
        self.hidden_layer_dim = hidden_layer_dim
        self.use_gpu = use_gpu
        self.gpu_memory_growth = gpu_memory_growth
        self.mixed_precision = mixed_precision
        
        # Configure GPU settings
        self._configure_gpu()
        
        self.autoencoder: Model | None = autoencoder
        self.encoder: Model | None = encoder
        self.strategy = self._setup_distribution_strategy()

    def _configure_gpu(self) -> None:
        """Configure GPU settings for optimal performance."""
        if not self.use_gpu:
            # Force CPU usage
            tf.config.set_visible_devices([], 'GPU')
            logging.info("GPU disabled, using CPU only")
            return
            
        # Get available GPUs
        gpus = tf.config.experimental.list_physical_devices('GPU')
        
        if not gpus:
            logging.warning("No GPU devices found, falling back to CPU")
            return
            
        logging.info(f"Found {len(gpus)} GPU(s): {[gpu.name for gpu in gpus]}")
        
        try:
            # Configure memory growth for each GPU
            for gpu in gpus:
                if self.gpu_memory_growth:
                    tf.config.experimental.set_memory_growth(gpu, True)
                    logging.info(f"Enabled memory growth for {gpu.name}")
                else:
                    # Alternative: set memory limit (uncomment and adjust as needed)
                    # tf.config.experimental.set_memory_limit(gpu, 4096)  # 4GB limit
                    pass
                    
            # Enable mixed precision if requested
            if self.mixed_precision:
                policy = tf.keras.mixed_precision.Policy('mixed_float16')
                tf.keras.mixed_precision.set_global_policy(policy)
                logging.info("Enabled mixed precision training")
                
        except RuntimeError as e:
            logging.error(f"GPU configuration error: {e}")
            logging.info("GPU configuration must be set before creating models")

    def _setup_distribution_strategy(self) -> tf.distribute.Strategy:
        """Setup distribution strategy for multi-GPU training."""
        if not self.use_gpu:
            return tf.distribute.get_strategy()  # Default strategy for CPU
            
        gpus = tf.config.experimental.list_physical_devices('GPU')
        
        if len(gpus) > 1:
            # Multi-GPU strategy
            strategy = tf.distribute.MirroredStrategy()
            logging.info(f"Using MirroredStrategy with {strategy.num_replicas_in_sync} GPUs")
        elif len(gpus) == 1:
            # Single GPU strategy
            strategy = tf.distribute.OneDeviceStrategy(device="/gpu:0")
            logging.info("Using OneDeviceStrategy with single GPU")
        else:
            # CPU fallback
            strategy = tf.distribute.get_strategy()
            logging.info("Using default strategy (CPU)")
            
        return strategy

    @classmethod
    def from_model(
        cls, 
        autoencoder: Model, 
        encoder: Model,
        use_gpu: bool = True,
        gpu_memory_growth: bool = True,
        mixed_precision: bool = False,
    ) -> "KerasAutoencoder":
        return cls(
            autoencoder=autoencoder, 
            encoder=encoder,
            use_gpu=use_gpu,
            gpu_memory_growth=gpu_memory_growth,
            mixed_precision=mixed_precision,
        )

    @classmethod
    def from_dataset_analysis(
        cls,
        dataset_analysis: DatasetAnalysis,
        bottleneck_layer_dim: int,
        hidden_layer_dim: List[int],
        use_gpu: bool = True,
        gpu_memory_growth: bool = True,
        mixed_precision: bool = False,
    ) -> "KerasAutoencoder":
        instance = cls(
            bottleneck_layer_dim=bottleneck_layer_dim,
            hidden_layer_dim=hidden_layer_dim,
            use_gpu=use_gpu,
            gpu_memory_growth=gpu_memory_growth,
            mixed_precision=mixed_precision,
        )
        
        # Build model within distribution strategy scope
        with instance.strategy.scope():
            autoencoder, encoder = cls._build_model(
                dataset_analysis, 
                bottleneck_layer_dim, 
                hidden_layer_dim,
                mixed_precision=mixed_precision,
            )
            
        instance.autoencoder = autoencoder
        instance.encoder = encoder
        return instance

    def fit(
        self,
        x: Dict[str, np.ndarray],
        y: Dict[str, np.ndarray],
        epochs: int,
        batch_size: int,
    ) -> None:
        # Adjust batch size for multi-GPU training
        effective_batch_size = batch_size * self.strategy.num_replicas_in_sync
        
        logging.info(f"Training with batch size {effective_batch_size} "
                    f"({batch_size} per replica × {self.strategy.num_replicas_in_sync} replicas)")
        
        # Use strategy scope for training
        with self.strategy.scope():
            callbacks = [
                EarlyStopping(
                    monitor='val_loss', 
                    patience=2, 
                    restore_best_weights=True
                )
            ]
            
            # Add GPU memory monitoring callback if available
            try:
                if self.use_gpu and tf.config.experimental.list_physical_devices('GPU'):
                    callbacks.append(tf.keras.callbacks.experimental.BackupAndRestore('./tmp/backup'))
            except AttributeError:
                pass  # Callback not available in this TF version
                
            self.autoencoder.fit(
                x, y, 
                epochs=epochs, 
                batch_size=effective_batch_size,
                validation_split=0.2, 
                shuffle=True, 
                callbacks=callbacks
            )

    def embed(self, x: pd.DataFrame) -> np.ndarray:
        with self.strategy.scope():
            return self.encoder.predict(x)

    @classmethod
    def _build_model(
        cls,
        dataset_analysis: DatasetAnalysis,
        bottleneck_layer_dim: int,
        hidden_layer_dim: List[int],
        mixed_precision: bool = False,
    ) -> Tuple[Model, Model]:
        inputs, bottleneck_layer = cls._build_encoder_part(
            dataset_analysis, 
            bottleneck_layer_dim, 
            hidden_layer_dim
        )
        outputs = cls._build_decoder_part(
            bottleneck_layer, 
            dataset_analysis, 
            bottleneck_layer_dim, 
            hidden_layer_dim
        )

        autoencoder = Model(inputs=inputs, outputs=outputs)
        encoder = Model(inputs=inputs, outputs=bottleneck_layer)

        losses = {}
        loss_weights = {}

        losses[NUMERICAL_OUTPUTS_KEY] = "mse"
        loss_weights[NUMERICAL_OUTPUTS_KEY] = 1.0

        for feature_name in dataset_analysis.categorical_columns.columns:
            if dataset_analysis.categorical_features_loss_weights is not None:
                loss_weights[f"{feature_name}_outputs"] = dataset_analysis.categorical_features_loss_weights[feature_name]
            else:
                loss_weights[f"{feature_name}_outputs"] = 1.0
            losses[f"{feature_name}_outputs"] = "sparse_categorical_crossentropy"

        # Adjust optimizer for mixed precision
        optimizer = Adam(learning_rate=0.001)
        if mixed_precision:
            optimizer = tf.keras.mixed_precision.LossScaleOptimizer(optimizer)

        autoencoder.compile(
            optimizer=optimizer, 
            loss=losses, 
            loss_weights=loss_weights
        )

        return autoencoder, encoder

    @classmethod
    def _build_encoder_part(
        cls,
        dataset_analysis: DatasetAnalysis,
        bottleneck_layer_dim: int,
        hidden_layer_dim: List[int],
    ) -> Tuple[Dict[str, Layer], Layer]:
        inputs = {}
        embeddings = []

        numerical_inputs_size = len(dataset_analysis.numerical_columns.columns)
        numerical_inputs_layer = Input(shape=(numerical_inputs_size,), name=NUMERICAL_INPUTS_FEATURES_KEY)

        inputs[NUMERICAL_INPUTS_FEATURES_KEY] = numerical_inputs_layer
        embeddings.append(numerical_inputs_layer)

        for (
            feature_name,
            feature,
        ) in dataset_analysis.categorical_columns.columns.items():
            categorical_input_layer = Input(shape=(1,), name=feature_name)
            inputs[feature_name] = categorical_input_layer

            embedding_layer = Embedding(
                input_dim=len(feature.vocabulary) + 1,
                output_dim=feature.embedding_dim,
                name=f"{feature_name}_embedding",
                
            )(categorical_input_layer)

            embedding_layer = Flatten(name=f"{feature_name}_embedding_flatten")(embedding_layer)
            embeddings.append(embedding_layer)

        all_features_layer = Concatenate()(embeddings)
        print(all_features_layer.shape)

        for index, hidden_layer_dim in enumerate(hidden_layer_dim):
            all_features_layer = LayerNormalization()(all_features_layer)
            all_features_layer = Dense(units=hidden_layer_dim, activation="leaky_relu", name=f"hidden_layer_{index}")(all_features_layer)
            all_features_layer = LayerNormalization()(all_features_layer)
            all_features_layer = Dropout(0.2)(all_features_layer)

        bottleneck_layer = Dense(units=bottleneck_layer_dim, activation="tanh", name="bottleneck_layer")(all_features_layer)

        return inputs, bottleneck_layer

    @classmethod
    def _build_decoder_part(
        cls,
        bottleneck_layer: Layer,
        dataset_analysis: DatasetAnalysis,
        bottleneck_layer_dim: int,
        hidden_layer_dim: List[int],
    ) -> Dict[str, Layer]:
        first_decoding_layer = Dense(units=bottleneck_layer_dim, activation="leaky_relu", name="first_decoding_layer")(bottleneck_layer)

        for index, hidden_layer_dim in enumerate(reversed(hidden_layer_dim)):
            first_decoding_layer = Dense(
                units=hidden_layer_dim,
                activation="relu",
                name=f"decoding_layer_{index}",
            )(first_decoding_layer)
            first_decoding_layer = Dropout(0.2)(first_decoding_layer)

        outputs = {}

        numerical_outputs = Dense(
            units=len(dataset_analysis.numerical_columns.columns),
            name="numerical_outputs",
        )(first_decoding_layer)
        outputs[NUMERICAL_OUTPUTS_KEY] = numerical_outputs

        for (
            feature_name,
            feature,
        ) in dataset_analysis.categorical_columns.columns.items():
            categorical_output_layer = Dense(
                units=len(feature.vocabulary) + 1,
                name=f"{feature_name}_outputs",
                activation="softmax",
            )(first_decoding_layer)
            outputs[f"{feature_name}_outputs"] = categorical_output_layer

        return outputs

    def save(self, path: str) -> None:
        with self.strategy.scope():
            self.autoencoder.save(f"{path}/autoencoder.keras")
            self.encoder.save(f"{path}/encoder.keras")

    @classmethod
    def load(
        cls, 
        path: str,
        use_gpu: bool = True,
        gpu_memory_growth: bool = True,
        mixed_precision: bool = False,
    ) -> "KerasAutoencoder":
        instance = cls(
            use_gpu=use_gpu,
            gpu_memory_growth=gpu_memory_growth,
            mixed_precision=mixed_precision,
        )
        
        with instance.strategy.scope():
            autoencoder = load_model(f"{path}/autoencoder.keras")
            encoder = load_model(f"{path}/encoder.keras")
            
        instance.autoencoder = autoencoder
        instance.encoder = encoder
        return instance

    def get_gpu_info(self) -> Dict[str, any]:
        """Get information about GPU configuration and usage."""
        info = {
            "use_gpu": self.use_gpu,
            "gpu_memory_growth": self.gpu_memory_growth,
            "mixed_precision": self.mixed_precision,
            "strategy": type(self.strategy).__name__,
            "num_replicas": self.strategy.num_replicas_in_sync,
        }
        
        gpus = tf.config.experimental.list_physical_devices('GPU')
        info["available_gpus"] = len(gpus)
        info["gpu_names"] = [gpu.name for gpu in gpus]
        
        if gpus:
            try:
                # Get GPU memory info if available
                gpu_details = []
                for gpu in gpus:
                    details = tf.config.experimental.get_device_details(gpu)
                    gpu_details.append(details)
                info["gpu_details"] = gpu_details
            except:
                pass  # Some TF versions don't support this
                
        return info
