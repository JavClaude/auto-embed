from dataclasses import dataclass


@dataclass
class WhatIsMyClassifiedRecommendationsQuery:
    classified_ref: str
