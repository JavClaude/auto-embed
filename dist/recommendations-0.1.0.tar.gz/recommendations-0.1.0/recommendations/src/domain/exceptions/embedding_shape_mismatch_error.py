class EmbeddingShapeMismatchError(Exception):
    pass